<section class="bg-lightgrey nopadding">
    <div class="agenda-ticker-wrapper">
        <div class="agenda-ticker-controls">
            <button class="agenda-ticker-prev">
                <i class="fa-solid fa-arrow-left"></i>
            </button>
            <button class="agenda-ticker-next">
                <i class="fa-solid fa-arrow-right"></i>
            </button>
        </div>
        <div class="container nopadding">
            <div class="agenda-slider">
                <div class="agenda-slider-item-wrapper ">
                    <?php foreach ( $events as $event ) :  ?>
                    <article class="agenda-slider-item shadow">
                        <span class="item-date font-cond orange center">
                            <span class="item-date-day"><?= tribe_get_start_date( $post ,false, 'j'); ?></span>
                            <span class="item-date-month"><?= tribe_get_start_date( $post ,false, 'F'); ?></span>
                            <span class="item-date-year"><?= tribe_get_start_date( $post ,false, 'Y'); ?></span>    
                        </span>
                        <div class="item-content">
                            <div class="detail-info">
                                <h3 class="item-title font-cond"><?= $event->post_title;?></h3>
                                <p class=""><?= $event->post_excerpt;?></p>
                            </div>
                        </div>
                        <a href="<?= tribe_get_event_link($post, false); ?>" class="item-cta btn btn-orange-secondary">En savoir plus</a>
                    </article>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</section>